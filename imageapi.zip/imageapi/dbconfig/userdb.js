module.exports={
  
    //define db url/ with DB name
    url:'mongodb://localhost:27017/digisaksham'
}