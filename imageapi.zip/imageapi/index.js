var express = require("express");
var fs = require("fs");
var multer=require("multer");
var cors=require("cors");
const path = require('path');
var app = express();
var port = 3000;
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));


/*********Provide authentication here******* */
app.use(cors());





app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');
    res.setHeader('Access-Control-Allow-Methods', 'POST,GET,PATCH,PUT,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type , Accept');
  
    next();
  });


  /********database connectivity****** */
const dbConfig = require('./dbconfig/userdb');
const mongoose = require('mongoose');

mongoose.connect(dbConfig.url, { useNewUrlParser: true })
    .then(() => {
        console.log("Successfully connected to the database");
    }).catch(err => {
        console.log('Could not connect to the database. Exiting now...');
        process.exit();
    });


    /********create schema in database****** */

var nameSchema = new mongoose.Schema({
    UserId:Number,
    fullname:String,
    email:String,
    password:String,
    phoneno:Number,
    passwordconfirm:String,
    teachingid:Number,
    followingId:Number,
    materialId:Number,
    identifyid:Number,
    id:Number,
    name:String,
    categories:String,
    inputfile:String, 
    image:String,
    addonarray:[], 
    havefollowing: String,
    identify: String,
    image:String,
    imagefile:String,
    password: String,
    passwordconfirm: String,
    phonno: Number,
    teachingonline: String,
    trainningmaterial: String,
    coursename:String,
    clientdocument:String,
    ppt:String,
    pdf:String,
    video:String,
    resume:String,
    categories:String,
    imagePath:String,
      
    
});
var User = mongoose.model("User", nameSchema);


/****** connect with index.html file***** */

app.get("/", (req, res) => {
    res.sendFile(__dirname + "/index.html");
});




/********uploading image******** */

let storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, "./uploads");
    
    },
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '-' + Date.now() + '.' + path.extname(file.originalname));
    }
   
});

let upload = multer({storage: storage});

/*******Post method used for get data***** */


app.post("", upload.single('document'),(req, res, next)=> {
 
   

  var myData = new User(req.body);
  
     myData.save()
        .then(item => {
            res.send("Name saved to database");
            
        })
        .catch(err => {
            res.status(400).send("Unable to save to database");
        });
        
       
     
       
});




app.listen(port, () => {
    console.log("Server listening on port " + port);
});
